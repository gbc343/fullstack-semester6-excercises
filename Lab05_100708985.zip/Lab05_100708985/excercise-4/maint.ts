import {Customer} from './customer'

let customer = new Customer ("John", "Smith", 45);
customer.greeter();
customer.GetAge();