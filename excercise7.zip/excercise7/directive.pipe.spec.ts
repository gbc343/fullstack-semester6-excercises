import { DirectivePipe } from './directive.pipe';

describe('DirectivePipe', () => {
  it('create an instance', () => {
    const pipe = new DirectivePipe();
    expect(pipe).toBeTruthy();
  });
});
